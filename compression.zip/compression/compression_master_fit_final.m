clear all;close all;clc

num_doe = 17;
% base = ["C:\Users\harrcono\Box\NIEHS Hydrogel R01\DOE_PVA_NaAlg_firstpass\Compression\compression\Master_comp_mod"]; % johnson comp
base = ["compression\Master_comp_mod"]; %personal
rep = ["1","2","3"];
day = ["1","30"];
c = 1;
for i=1:num_doe
    doe = num2str(i);
    l = 0;
    for j = 1:3;
    file(c+l) = base + "\" + "DOE" + "_" + doe + "_" + day(1) + "_" + rep(j);
    file(c + 3 + l) = base + "\" + "DOE" + "_" + doe + "_" + day(2) + "_" + rep(j);
    l = j;
    end
c = c+l*2;
end

for k = 1:length(file);
opts = spreadsheetImportOptions("NumVariables", 7);

% Specify sheet and range
opts.Sheet = "Axial - 1";
opts.DataRange = "A4:G490";


opts.VariableNames = ["Steptime", "Modulus", "Time", "Normalstress", "Axialforce", "Gap"];
opts.VariableTypes = ["double", "double", "double", "double", "double", "double"];

% Import the data
% naalg1hrbead1S1 = readtable("\Users\conor\Box\NIEHS Hydrogel R01\DOE_PVA_NaAlg_firstpass\Compression\compression\0.6% PVA 1.5%NaAlg 75min CL\pva_0p6_naalg_1p5_compression_test_2_2022_01_04.xls", opts, "UseExcel", false);
naalg1hrbead1S1 = readtable(file(k), opts, "UseExcel", false);

forcecheck = 0.00005;
%% Clear temporary variables
clear opts
force = naalg1hrbead1S1{:,5};
gap = naalg1hrbead1S1{:,6};
gap = gap(force>forcecheck);
di(k) = gap(1);
end
numreps = 3;
c = 1;
for j = 1:num_doe*2
    diee(c:c+2) = mean(di(c:c+2));
    c=c+3;
end

for k = 1:length(file);    
%% Setup the Import Options and import the data
opts = spreadsheetImportOptions("NumVariables", 7);

% Specify sheet and range
opts.Sheet = "Axial - 1";
opts.DataRange = "A4:G490";


opts.VariableNames = ["Steptime", "Modulus", "Time", "Normalstress", "Axialforce", "Gap"];
opts.VariableTypes = ["double", "double", "double", "double", "double", "double"];

% Import the data
% naalg1hrbead1S1 = readtable("\Users\conor\Box\NIEHS Hydrogel R01\DOE_PVA_NaAlg_firstpass\Compression\compression\0.6% PVA 1.5%NaAlg 75min CL\pva_0p6_naalg_1p5_compression_test_2_2022_01_04.xls", opts, "UseExcel", false);
naalg1hrbead1S1 = readtable(file(k), opts, "UseExcel", false);


%% Clear temporary variables
clear opts


force = naalg1hrbead1S1{:,5};
gap = naalg1hrbead1S1{:,6};

gapint = 1;
force = force(gapint:end);

gap = gap(gapint:end);
gap = gap(force>forcecheck);
force = force(force>forcecheck);


diam(k) = gap(1);



D = diam(k)*10^(-6);
% D = diee(k)*10^(-6);

A = pi*D^2/4;


strain = [];
for i = 1:length(gap);
    
strainc(i,:) = (gap(1)-gap(i))/gap(1)*100;
strain(i,:) = (gap(1).*10.^(-6)-gap(i).*10.^(-6)).^(1.5);
end



stress = 3./4*force.*(gap(1).*10.^(-6))^(-1./2);


oldstress = stress;
oldstrain = strain;

stress = [];
stress = smoothdata(oldstress,'loess',20);




diffstress = abs(diff(stress,2));

stresscheck1 = 1;
stresscheck2 = 0;
ccheck = 0;
errc = 0.005;
ep = 0;
while stresscheck2 < (stresscheck1+errc)

    intt = find(strainc>5,1);
    starttol(k) = max(diffstress(1:intt));
    ii = find(abs(diff(stress(intt:end),2))>starttol(k)*0.50,1);
    ende = find(strainc>(10+ccheck),1);
    avetol(k) = max(diffstress(ii:ende));
    ii2 = find(abs(diff(stress(ii:end),2))>avetol(k)*(1-ep),1);
    stresscheck1 = force(ii);
    stresscheck2 = force(ii2);
    ccheck = ccheck + 1;
end



linear_x = strain(ii:(ii2+ii));
linear_y = stress(ii:(ii2+ii));

check = k
m = polyfit(linear_x,linear_y,1);
% m = linear_x(:)\linear_y(:);
x = [0:1:50];
y = m(1)*x + m(2);
% y = m(1)*x;
realcomp = m(1);
comp(k) = m(1);
maxstress = max(stress);

%% evaluate the linear region 
% 
% figure(k)
% hold on
% subplot(2,1,1)
% title(file(k));
% hold on
% plot(x,y,'m-')
% plot(oldstrain,oldstress,'b')
% plot(strain,stress,'r--')
% scatter([strain(ii) strain(ii2+ii)], [stress(ii) stress(ii2+ii)],30)
% ylim([0 maxstress/4])
% xlim([0 50e-06])
% % plot(straint,ys)
% % plot(f,strain,stress)
% hold off
% subplot(2,1,2)
% hold on
% plot(diffstress)
% plot([0 300],[avetol(k) avetol(k)]);
% % plot([diffstrain(1) diffstrain(end)],[stressdiffave(k) stressdiffave(k)],'k--');
% % plot([diffstrain(1) diffstrain(end)],[stressdiffave(k)*3 stressdiffave(k)*3],'r--');
% % plot([diffstrain(1) diffstrain(end)],[stressdiffave(k)/2 stressdiffave(k)/2],'g--');
% % plot([diffstrain(1) diffstrain(end)],[30 30],'m--');
% % plot([diffstrain(1) diffstrain(end)],[stressdiffmax(k) stressdiffmax(k)],'b--');
% ylim([0 100])
% xlim([0 350])
% hold off
% hold off



end

j = 1;
c = 1;
diam = diam*10^(-6);

j=1;
centerpoints = 3; % how many you include 
for l = 1:1:(num_doe-centerpoints+1) 
    doe = num2str(l);
    compave(l,c) = mean([comp(j:j+2)]);
    compave(l,c+1) = mean([comp(j+3:j+5)]);
    compstd(l,c) = std([comp(j:j+2)]);
    compstd(l,c+1) = std([comp(j+3:j+5)]);
    name1(l,c) = "DOE" + "-" + doe + "-" + day(1);
    name1(l,c+1) = "DOE" + "-" + doe + "-" + day(2);
    diamave(l,c) = mean([diam(j:j+2)]);
    diamave(l,c+1) = mean([diam(j+3:j+5)]);
    diamstd(l,c) = std([diam(j:j+2)]);
    diamstd(l,c+1) = std([diam(j+3:j+5)]);
    diamdiff(l) = mean([diam(j:j+2)-diamave(l,c+1)]/diamave(l,c+1)*100);
    diamdiffstd(l) = std([diam(j:j+2)-diamave(l,c+1)]/diamave(l,c+1)*100)
    comptest(l,c) = (comp(j)-comp(j+3))./comp(j);
    testvar = j+1;
    comptest(l,c+1) = (comp(testvar)-comp(testvar+3))./comp(testvar);
    testvar2 = j+2;
    comptest(l,c+2) = (comp(testvar2)-comp(testvar2+3))./comp(testvar2);
    t(l,c) = l;
    t(l,c+1) = l;
    c = 1;
    j = j+6;
    xtickid(l) = l;

end

c=1;
j=j-6;
for l = (num_doe-centerpoints+1):num_doe
    z = l- (num_doe-centerpoints+1)+1;
    compcenter1(z,c) = comp(j);
    compcenter30(z,c) = comp(j+3);
    comptest(l,c) = (comp(j)-comp(j+3))./comp(j);
    testvar = j+1;
    compcenter1(z,c+1) = comp(testvar);
    compcenter30(z,c+1) = comp(testvar+3);
    comptest(l,c+1) = (comp(testvar)-comp(testvar+3))./comp(testvar);
    testvar2 = j+2;
    compcenter1(z,c+2) = comp(testvar2);
    compcenter30(z,c+2) = comp(testvar2+3);
    comptest(l,c+2) = (comp(testvar2)-comp(testvar2+3))./comp(testvar2);
    c=1;
    j = j+6;
end
% compave(15,1) = mean(mean([compcenter1((num_doe-centerpoints+1):num_doe,:)]));
% compave(15,2) = mean(mean([compcenter30((num_doe-centerpoints+1):num_doe,:)]));
% compstd(15,1) = std([compcenter1((num_doe-centerpoints+1):num_doe,:)]);
% compstd(15,2) = std([compcenter30((num_doe-centerpoints+1):num_doe,:)]);

compave((num_doe-centerpoints+1),1) =  mean(compcenter1(~isnan(compcenter1)));
compave((num_doe-centerpoints+1),2) =  mean(compcenter30(~isnan(compcenter30)));
compstd((num_doe-centerpoints+1),1) =  std(compcenter1(~isnan(compcenter1)));
compstd((num_doe-centerpoints+1),2) =  std(compcenter30(~isnan(compcenter30)));
% compave(16:17,2) = NaN;
% compstd(16:17,2) = NaN;
% diamave(16:17,2) = NaN;
% diamdiff(16:17) = NaN;
% cats = categorical(name1);
% cats = reordercats(cats,name1);

for i = 1:(num_doe-centerpoints+1)
    compnd(i,1) = mean([comptest(i,:)]);
    compndstd(i,1) =  std([comptest(i,:)]);
end
cntrloss = comptest(((num_doe-centerpoints+1):num_doe),1:3);
compnd((num_doe-centerpoints+1)) = mean(cntrloss(~isnan(cntrloss)));
compndstd((num_doe-centerpoints+1)) = std(cntrloss(~isnan(cntrloss)));
% 
% compave(15,1) = mean(compave(15:17,1));
% compstd(15,1) = std(compave(15:17,1))*compstd(15,1)*compstd(16,1)*compstd(17,1);
% compave(15,2) = mean(compave(15:17,2));
% compstd(15,2) = std(compave(15:17,2))*compstd(15,2)*compstd(16,2)*compstd(17,2);
% compnd(15,1) =  mean(compnd(15:17,1));
% compndstd(15,1) = std(compnd(15:17,1))*compndstd(15,1)*compndstd(16,1)*compndstd(17,1);
% compave((num_doe-centerpoints+2):num_doe,:) = NaN;
% compstd((num_doe-centerpoints+2):num_doe,:) = NaN;
% compnd((num_doe-centerpoints+2):num_doe,:) = NaN;
% compndstd((num_doe-centerpoints+2):num_doe,:) = NaN;
% compteststd(15,1) = std(comptest(15:17,1))

% compave(15,1) = mean([comp(85:87),comp(91:93),comp(97:99)]);
% compstd(15,1) = std([comp(85:87),comp(91:93),comp(97:99)]);
% compave(15,2) = mean([comp(88:90),comp(94:96),comp(100:102)]);
% compstd(15,2) = std([comp(88:90),comp(94:96),comp(100:102)]);
% compave = compave./(10^6);
% compave(18:end,2)= NaN;
% compstd(18:end,2) = NaN;
% compstd = compstd./(10^6);
compave(~any(~isnan(compave), 2),:) = [];
compstd(~any(~isnan(compstd), 2),:) = [];
compnd(~any(~isnan(compnd), 2),:) = [];
compndstd(~any(~isnan(compndstd), 2),:) = [];

compndv = (compave(:,1)-compave(:,2))./(compave(:,1));
% compnd = compnd(~isnan(compnd))
% compnd = mean(comptest)
% compndstd = (compstd(:,1)-compstd(:,2))./(compstd(:,1))
asts = cell((num_doe-centerpoints+1),1,1);
for i = 1:length(asts);
asts{i} = '^{\ast}';
end
% ctext = [num2cell(compnd),asts(:)]
% t = ones(15,1);
% for z = 1:15;
%     t(z) = 1*z;
% end
compndv = (real(compave(:,1))-real(compave(:,2)))./(real(compave(:,1)));
ctext = [num2cell(compndv),asts(:)]
for i = 1:length(asts)
    e1 = real(compave(i,1));
    e30 = real(compave(i,2));
    sig1 = real(compstd(i,1));
    sig2 = real(compstd(i,2));
    compndvstd(i,1) = compndv(i,1)*sqrt(e30^2/(e1^2*(e1 - e30)^2)*sig1^2 + 1/(e1 - e30)^2*sig2^2); % from propogation of error sigma_x^2 = diff(x,a)^2*sigma_a^2 + diff(x,b)^2*sigma_b^2 ...
end
% compndvstd = ((1./compave(:,1)-(compave(:,1)-compave(:,2))./(compave(:,1).^2)).^2.*compstd(:,1).^2 + (-1./compave(:,1)).^2.*compstd(:,2).^2).^(1./2);
compave = real(compave)./(10^6);
% compave(18:end,2)= NaN;
% compstd(18:end,2) = NaN;
compstd = real(compstd)./(10^6);

figure(k+1)
hold on 
b = bar(t,compave);
b(1).FaceColor = '#005AB5';
b(1).EdgeColor = '#005AB5';
b(1).FaceAlpha = 0.4;
b(2).FaceColor = '#DC3220';
b(2).EdgeColor = '#DC3220';
b(2).FaceAlpha = 0.4;
b(1).LineWidth = 2;
b(2).LineWidth = 2;

[ngroups, nbars] = size(compave);
% Calculate the width for each bar group
groupwidth = min(0.8, nbars/(nbars + 1.5));
% Set the position of each error bar in the centre of the main bar
% Based on barweb.m by Bolu Ajiboye from MATLAB File Exchange
for i = 1:nbars
    % Calculate center of each bar
    x = (1:ngroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*nbars);
    errorbar(x, compave(:,i), compstd(:,i), 'k', 'linestyle', 'none','linewidth',2);
end


ax = gca;
ax.LineWidth = 3;

% ax.FontWeight = 'bold';
% set(gca, 'XTick',xtickid)
ax.XTick = xtickid;
ytickformat('%.2f')
% ylim([0 0.2])
legend([{'\boldmath$\mathsf{E_1}$'},{'\boldmath$\mathsf{E_{30}}$'}],'Position',[0.10 0.65 0.2 0.2],'Interpreter','latex') % position = [left bottom width height]
xlab = xlabel('\boldmath$\mathsf{Experiment \: No}$','Interpreter','latex','FontSize',20)
ylab = ylabel({"\boldmath$\mathsf{E \: [MPa]}$"},'Interpreter','latex')
ax.FontSize = 22;
% ax.Interpreter = 'latex';
box on
hold off

figure(k+2)
hold on


l = bar(t(:,1),compndv.*100)
lerr = errorbar(t(:,1),compndv.*100,compndvstd.*100,'LineStyle','none')

l.FaceColor = '#b3b3b3';

l.LineWidth = 2;
% lerr.Color = b(2).FaceColor;
lerr.Color = 'k';
lerr.LineWidth = 2;
lerr.CapSize = 5;
ax = gca;
ax.LineWidth = 3;
ax.FontSize = 22;
ax.FontWeight = 'bold';
ax.XTick = xtickid;
% ax.XTickLabelRotation = 45;
ylim([0 100])
xlim([0 16]);
% xticks([0 1 2])
% xticklabels({'','',''})

% legend([{'E_1'},{'E_{30}'}],'Position',[0.10 0.65 0.2 0.2]) % position = [left bottom width height]
xlab = xlabel("\boldmath$\mathsf{Experiment No}$",'Interpreter','latex','FontSize',24)
ylab = ylabel({"\boldmath$\mathsf{\mathit{\Delta} E \: [\%]}$"},'Interpreter','latex','FontSize',24,'FontWeight','bold')
box on
hold off


% 
% figure(k+2)
% hold on
% b = bar(t,diamave);
% b(1).LineWidth = 3;
% b(2).LineWidth = 3;
% [ngroups, nbars] = size(diamave);
% % Calculate the width for each bar group
% groupwidth = min(0.8, nbars/(nbars + 1.5));
% % Set the position of each error bar in the centre of the main bar
% % Based on barweb.m by Bolu Ajiboye from MATLAB File Exchange
% for i = 1:nbars
%     % Calculate center of each bar
%     x = (1:ngroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*nbars);
%     errorbar(x, diamave(:,i), diamstd(:,i), 'k', 'linestyle', 'none','linewidth',3);
% end
% % b.FaceColor = [1 1 1];
% % ylim([0 100]);
% box on
% hold off
% 
% c = 1;
% for j = 1:num_doe
%     doe = num2str(j);
%     percentdif(j) = abs((compave(c)-compave(c+1)))/(compave(c))*100;
%     name2(j) = "DOE" + "-" + doe;
%     c = c+2;
% end
% 
% cats = categorical(name2)
% cats = reordercats(cats,name2);
% figure(k+3)
% hold on
% b = bar(cats,diamdiff);
% b.LineWidth = 3;
% % b.FaceColor = [1 1 1];
% ylim([0 100]);
% box on
% hold off




% 
% figure(1)
% hold on
% scatter(strain,stress,1000,'o','LineWidth',2)
% plot(x,y,'LineWidth',3,'Color','r')
% ax = gca;
% 
% ylim([-4000 10000])
% xlim([0 60])
% text(10,5*10^3,['E =' num2str(round(m(1),0)) ' [Pa]'],'Interpreter','tex','FontSize',28,'Color','r')
% ax.LineWidth = 3;
% ax.FontSize = 20;
% ax.FontWeight = 'bold';
% % ax.YScale = 'log'
% xlab = xlabel('strain \epsilon','Interpreter','tex','FontSize',28)
% ylab = ylabel('stress \sigma','Interpreter','tex','FontSize',28)
% box on
% print('compression','-dpng')
% hold off