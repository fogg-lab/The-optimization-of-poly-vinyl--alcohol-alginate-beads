clear all;close all;clc

num_doe = 2;
% base = ["C:\Users\harrcono\Box\NIEHS Hydrogel R01\DOE_PVA_NaAlg_firstpass\Compression\compression\Master_comp_mod"]; % johnson comp
base = ["compression\verify"]; %personal
rep = ["1","2","3"];
day = ["1","30"];
c = 1;
for i=1:num_doe
    doe = num2str(i);
    l = 0;
    for j = 1:3;
    file(c+l) = base + "\" + "DOE" + "_" + doe + "_" + day(1) + "_" + rep(j);
    file(c + 3 + l) = base + "\" + "DOE" + "_" + doe + "_" + day(2) + "_" + rep(j);
    l = j;
    end
c = c+l*2;
end
forceint = 0.00005;
% for k = 1:length(file);
% opts = spreadsheetImportOptions("NumVariables", 7);
% 
% % Specify sheet and range
% opts.Sheet = "Axial - 1";
% opts.DataRange = "A4:G490";
% 
% % Specify column names and types
% % opts.VariableNames = ["Steptime", "Modulus", "Time", "Normalstress", "Axialforce", "Gap", "Strain"];
% % opts.VariableTypes = ["double", "double", "double", "double", "double", "double", "double"];
% opts.VariableNames = ["Steptime", "Modulus", "Time", "Normalstress", "Axialforce", "Gap"];
% opts.VariableTypes = ["double", "double", "double", "double", "double", "double"];
% 
% % Import the data
% % naalg1hrbead1S1 = readtable("\Users\conor\Box\NIEHS Hydrogel R01\DOE_PVA_NaAlg_firstpass\Compression\compression\0.6% PVA 1.5%NaAlg 75min CL\pva_0p6_naalg_1p5_compression_test_2_2022_01_04.xls", opts, "UseExcel", false);
% naalg1hrbead1S1 = readtable(file(k), opts, "UseExcel", false);
% 
% 
% %% Clear temporary variables
% clear opts
% force = naalg1hrbead1S1{:,5};
% gap = naalg1hrbead1S1{:,6};
% gap = gap(force>forceint);
% di(k) = gap(1);
% end
% numreps = 3;
% c = 1;
% for j = 1:num_doe*2
%     diee(c:c+2) = mean(di(c:c+2));
%     c=c+3;
% end
gapstart = [];
for k = 1:length(file);    
%% Setup the Import Options and import the data
opts = spreadsheetImportOptions("NumVariables", 7);

% Specify sheet and range
opts.Sheet = "Axial - 1";
opts.DataRange = "A4:G490";

% Specify column names and types
% opts.VariableNames = ["Steptime", "Modulus", "Time", "Normalstress", "Axialforce", "Gap", "Strain"];
% opts.VariableTypes = ["double", "double", "double", "double", "double", "double", "double"];
opts.VariableNames = ["Steptime", "Modulus", "Time", "Normalstress", "Axialforce", "Gap"];
opts.VariableTypes = ["double", "double", "double", "double", "double", "double"];

% Import the data
% naalg1hrbead1S1 = readtable("\Users\conor\Box\NIEHS Hydrogel R01\DOE_PVA_NaAlg_firstpass\Compression\compression\0.6% PVA 1.5%NaAlg 75min CL\pva_0p6_naalg_1p5_compression_test_2_2022_01_04.xls", opts, "UseExcel", false);
naalg1hrbead1S1 = readtable(file(k), opts, "UseExcel", false);


%% Clear temporary variables
clear opts


force = naalg1hrbead1S1{:,5};
gap = naalg1hrbead1S1{:,6};
gapstart(k) = find( diff(gap,2) > 4.6,1);
% gap = gap(force>0.003);
% force = force(force>0.003);

% gap = gap(force>0.003);
% force = force(force>0.003);
% gapintd = find(diff(gap)<-10,1);
% diam(k) = gap(gapintd);
gapint = gapstart(k);
force = force(gapint:end);
% force = force(:) - force(1);
gap = gap(gapint:end);
gap = gap(force>forceint);
force = force(force>forceint);
force = force(:) - force(1);
% strain = naalg1hrbead1S1{:,7};

diam(k) = gap(1);
% diam(k) = diee(k);
% diam(k) = 4000;
% 
% figure(k)
% hold on
% subplot(2,1,1)
% plot(gap)
% subplot(2,1,2)
% plot(diff(gap,2))
% hold off

% strain = -strain;
D = diam(k)*10^(-6);
% D = diee(k)*10^(-6);
% D = 20*10^(-3);
% D = 0.0002;
A = pi*D^2/4;
Arheo = pi*(25*10^(-3))^2/4;

% gap = naalg1hrbead1S1{:,6};


strain = [];
for i = 1:length(gap);
    
strainc(i,:) = (gap(1)-gap(i))/gap(1)*100;
strain(i,:) = (gap(1).*10.^(-6)-gap(i).*10.^(-6)).^(1.5);
end


% stress = force./A;
stress = 3./4*force.*D.^(-1./2);
% stress = naalg1hrbead1S1{:,4}.*Arheo./A;
% strain = strain(stress>0);

% stress = stress(stress>0);
% stress = stress(strain>0);
% strain = strain(strain>0);
% strain = strain(stress>0);
% stress = stress(stress>0);
% stress = stress(strain < 60);
% strain = strain(strain < 60);
oldstress = stress;
oldstrain = strain;
% datalength = 20;
% cutdata = length(stress)/datalength;
% stress = [];
% strain = [];
% p = 1;
% for s = 1:datalength
%     stress(s) = oldstress(p);
%     strain(s) = oldstrain(p);
%     p = p + round(cutdata);
% end
stress = [];
stress = smoothdata(oldstress,'loess',20);

% stress = movmean(oldstress,20);

% mtest = polyfit(strain,stress,2);
% stress = mtest(1).*strain.^2+mtest(2).*strain+mtest(3); % 2 polyfit
% stress = mtest(1).*strain.^3 + mtest(2).*strain.^2+mtest(3).*strain+mtest(4); % 3 polyfit
% stress = mtest(1).*strain.^4+mtest(2).*strain.^3+mtest(3).*strain.^2+mtest(4).*strain+mtest(5); % 4 polyfit

% stressfit = fit(strain,stress,
% tol = 10000000;
% [sp,ys,rho] = spaps(strain,stress,tol,ones(size(strain)));
% pmin = 1/(1+rho);
% straint = strain(1:length(ys));
% f = fit(strain,stress,'smoothingspline','SmoothingParam',0.7);
% plot(f,month,pressure)
% [ind, j] = find(abs(stress - ys)<=2.5);
% straint = strain;
% straint(ind) = NaN;
% straint = straint(~isnan(straint));
% ind = find(abs(strain - ys)<=0.001);
% strain1 = strain(ind);
% stress = smoothdata(stress,'loess','SmoothingFactor',0.8);
% strain = smoothdata(strain,'loess','SmoothingFactor',0.8);
% test = find(strain>2);
% stress = stress(test(1):end);
% strain = strain(test(1):end);
% stress = smoothdata(stress,'loess');
% stress = smoothdata(stress,'loess');
% stress = smoothdata(stress,'loess');

% TF = ischange(stress,'linear');
% brkpt = strain(TF==1);
% i=find( diff(stress,2)>0.5  ,1);
% linear_x = strain(1:i);
% linear_y = stress(1:i);
% ii = find(strain>25,1);
diffstress = abs(diff(stress,2));
% diffstrain = strain(1:length(diffstress));
% stressdiffmax(k) = max(abs(diff(stress(1:ii),2)));
% stressdiffmin(k) = min(abs(diff(stress(1:ii),2)));
% stressdiffave(k) = mean(abs(diff(stress(1:ii),2)));
% ii = find(strain>40,1);
% ii = 1;
stresscheck1 = 1;
stresscheck2 = 0;
ccheck = 0;
errc = 0.005;
ep = 0;
% 1e-06;
while stresscheck2 < (stresscheck1+errc)

    intt = find(strainc>5,1);
    starttol(k) = max(diffstress(1:intt));
    ii = find(abs(diff(stress(intt:end),2))>starttol(k)*0.50,1);
    ende = find(strainc>(20+ccheck),1);
    avetol(k) = max(diffstress(ii:ende));
    ii2 = find(abs(diff(stress(ii:end),2))>avetol(k)*(1-ep),1);
    stresscheck1 = force(ii);
    stresscheck2 = force(ii2);
    ccheck = ccheck + 1;
end

% while stresscheck2 < (stresscheck1+errc)
% 
%     intt = find(strainc>5,1);
%     starttol(k) = max(diffstress(1:intt));
%     ii = find(abs(gradient(gradient(stress(intt:end))))>starttol(k)*0.50,1);
%     ende = find(strainc>(20+ccheck),1);
%     avetol(k) = max(diffstress(ii:ende));
%     ii2 = find(abs(gradient(gradient(stress(ii:end))))>avetol(k)*(1-ep),1);
%     stresscheck1 = force(ii);
%     stresscheck2 = force(ii2);
%     ccheck = ccheck + 1;
% end

% diamtest(k) = mean([gap(ii)])*10^(-6);
% A2 = pi*diamtest(k)^2/4;
% stress = stress.*(A./A2);
% % i = 1;
% i2 = find(strain(i:end)>25,1);

% i = find(strain>1,1);
% i2 = find(strain(i:end)>35,1);
linear_x = strain(ii:(ii2+ii));
linear_y = stress(ii:(ii2+ii));
% linear_x = strain(strain>brkpt(1) & strain< brkpt(end));
% linear_y = stress(strain>brkpt(1) & strain< brkpt(end));

% linear_x = strain(strain>brkpt(1) & strain< brkpt(end));
% linear_y = stress(strain>brkpt(1) & strain< brkpt(end))

% strainx = strain(strain>5 & strain<20);
% stressy = stress(strain>5 & strain<20);
check = k
m = polyfit(linear_x,linear_y,1);
% m = linear_x(:)\linear_y(:);
x = [0:1:50];
% y = m(1)*x;
y = m(1)*x+m(2);
realcomp = m(1);
comp(k) = m(1);
maxstress = max(stress);


% figure(k)
% hold on
% subplot(2,1,1)
% title(file(k));
% hold on
% plot(x,y,'m-')
% plot(oldstrain,oldstress,'b')
% plot(strain,stress,'r--')
% scatter([strain(ii) strain(ii2+ii)], [stress(ii) stress(ii2+ii)],30)
% ylim([0 maxstress/4])
% xlim([0 50e-06])
% % plot(straint,ys)
% % plot(f,strain,stress)
% hold off
% subplot(2,1,2)
% hold on
% plot(diffstress)
% plot([0 300],[avetol(k) avetol(k)]);
% % plot([diffstrain(1) diffstrain(end)],[stressdiffave(k) stressdiffave(k)],'k--');
% % plot([diffstrain(1) diffstrain(end)],[stressdiffave(k)*3 stressdiffave(k)*3],'r--');
% % plot([diffstrain(1) diffstrain(end)],[stressdiffave(k)/2 stressdiffave(k)/2],'g--');
% % plot([diffstrain(1) diffstrain(end)],[30 30],'m--');
% % plot([diffstrain(1) diffstrain(end)],[stressdiffmax(k) stressdiffmax(k)],'b--');
% ylim([0 100])
% xlim([0 350])
% hold off
% hold off
% 
figure(k)
hold on 
pl = plot(x,y,'m-','LineWidth',3);
sc = scatter(oldstrain,oldstress,50,'k');
annotation('textarrow',[0.70 0.60],[0.45 0.45],'String','\boldmath$\mathsf{\: E}$','LineWidth',2,'Interpreter','latex','FontSize',26)
% text(3*10^(-5),1.5,'E','Interpreter','latex','FontSize',22)
ax = gca;
ax.LineWidth = 3;
ax.FontSize = 26;
ax.XAxis.Exponent = 0;
ax.FontWeight = 'bold';
ax.TickLabelInterpreter = 'latex';
ylab1 = ylabel({'';'\boldmath$\mathsf{\frac{3}{4} \: F \: D^{-0.5} \: / \: N m^{-0.5} }$'},'FontSize',26);
xlab1 = xlabel('\boldmath$\mathsf{(D-D^{\prime})^{1.5} \: / \: m^{1.5}}$','FontSize',26);
ylab1.Interpreter = 'latex';
xlab1.Interpreter = 'latex';
xlim([0 5*10^(-5)])
ylim([0 5])
yticks([0.0 2.5 5.0])
xticks([0 2.5 5]*10^(-5))
xticklabels([{'0.0','2.5e-5','5.0e-5'}])
ytickformat('%.1f')
leg = legend([sc,pl],[{'data';'fit'}],'Location','NorthWest','Interpreter','latex','FontSize',26);
box on
hold off


end

j = 1;
c = 1;
diam = diam*10^(-6);
% for l = 1:1:num_doe 
%     doe = num2str(l);
%     compave(c) = mean([comp(j:j+2)]);
%     compave(c+1) = mean([comp(j+3:j+5)]);
%     compstd(c) = std([comp(j:j+2)]);
%     compstd(c+1) = std([comp(j+3:j+5)]);
%     name1(c) = "DOE" + "-" + doe + "-" + day(1);
%     name1(c+1) = "DOE" + "-" + doe + "-" + day(2);
%     diamave(c) = mean([diam(j:j+2)]);
%     diamave(c+1) = mean([diam(j+3:j+5)]);
%     diamstd(c) = std([diam(j:j+2)]);
%     diamstd(c+1) = std([diam(j+3:j+5)]);
%     t(c) = l;
%     t(c+1) = l;
%     c = c+2;
%     j = j+6;
% 
% end
j=1;
centerpoints = 1; % how many you include 
for l = 1:1:(num_doe-centerpoints+1) 
    doe = num2str(l);
    compave(l,c) = mean([comp(j:j+2)]);
    compave(l,c+1) = mean([comp(j+3:j+5)]);
    compstd(l,c) = std([comp(j:j+2)]);
    compstd(l,c+1) = std([comp(j+3:j+5)]);
    name1(l,c) = "DOE" + "-" + doe + "-" + day(1);
    name1(l,c+1) = "DOE" + "-" + doe + "-" + day(2);
    diamave(l,c) = mean([diam(j:j+2)]);
    diamave(l,c+1) = mean([diam(j+3:j+5)]);
    diamstd(l,c) = std([diam(j:j+2)]);
    diamstd(l,c+1) = std([diam(j+3:j+5)]);
    diamdiff(l) = mean([diam(j:j+2)-diamave(l,c+1)]/diamave(l,c+1)*100);
    diamdiffstd(l) = std([diam(j:j+2)-diamave(l,c+1)]/diamave(l,c+1)*100)
    t(l,c) = l;
    t(l,c+1) = l;
    c = 1;
    j = j+6;
    xtickid(l) = l;

end
% compave(3,2) = NaN;
% compstd(2:3,2) = NaN;
% diamave(16:17,2) = NaN;
% diamdiff(16:17) = NaN;
% cats = categorical(name1);
% cats = reordercats(cats,name1);
% compave(15,1) = mean(compave(15:17,1));
% compstd(15,1) = std(compave(15:17,1))*compstd(15,1)*compstd(16,1)*compstd(17,1);
% compave(15,2) = mean(compave(15:17,2));
% compstd(15,2) = std(compave(15:17,2))*compstd(15,2)*compstd(16,2)*compstd(17,2);

% compave(15,1) = mean([comp(85:87),comp(91:93),comp(97:99)]);
% compstd(15,1) = std([comp(85:87),comp(91:93),comp(97:99)]);
% compave(15,2) = mean([comp(88:90),comp(94:96),comp(100:102)]);
% compstd(15,2) = std([comp(88:90),comp(94:96),comp(100:102)]);
compave = compave./(10^6);
% compave(18:end,2)= NaN;
% compstd(18:end,2) = NaN;
compstd = compstd./(10^6);

compnd = (compave(:,1)-compave(:,2))./(compave(:,1));
asts = cell((num_doe-centerpoints+1),1,1);
for i = 1:length(asts);
asts{i} = '^{\ast}';
end
ctext = [num2cell(compnd),asts(:)]
% t = ones(15,1);
% for z = 1:15;
%     t(z) = 1*z;
% end

figure(k+1)
hold on 
b = bar(t,compave);
b(1).FaceColor = '#005AB5';
b(1).EdgeColor = '#005AB5';
b(1).FaceAlpha = 0.4;
b(2).FaceColor = '#DC3220';
b(2).EdgeColor = '#DC3220';
b(2).FaceAlpha = 0.4;
b(1).LineWidth = 2;
b(2).LineWidth = 2;
% b.FaceColor = [1 1 1];
% for i = 1:length(compnd)
%     text((t(i)-0.25),(max(compave(i,1))+0.05),sprintf('%0.2f%s',ctext{i,:}),'FontSize',24);
% end
% text(2.25,0.16,['$\mathrm{^{\ast} loss = \frac{E_1-E_{30}}{E_1}}$'],'Interpreter','latex','FontSize',35)
[ngroups, nbars] = size(compave);
% Calculate the width for each bar group
groupwidth = min(0.8, nbars/(nbars + 1.5));
% Set the position of each error bar in the centre of the main bar
% Based on barweb.m by Bolu Ajiboye from MATLAB File Exchange
high = 1.08;
low = 1.05;
asth = 1.3;
x = [];
for i = 1:nbars
    % Calculate center of each bar
    x(i,:) = (1:ngroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*nbars);
    errorbar(x(i,:), compave(:,i), compstd(:,i), 'k', 'linestyle', 'none','linewidth',2,'CapSize',10);
end
plot([x(1,1),x(1,1)], [(compave(1,1)+compstd(1,1))*low ((compave(1,1)+compstd(1,1))*low+0.005)],'k-')
plot([x(1,2),x(1,2)], [((compave(2,1)+compstd(2,1))*low+0.0025) ((compave(2,1)+compstd(2,1))*low+0.005)],'k-')
plot([x(1,1),x(2,1)], [((compave(1,1)+compstd(1,1))*low+0.005) ((compave(1,1)+compstd(1,1))*low+0.005)],'k-')
plot([x(1,2),x(2,2)], [((compave(2,1)+compstd(2,1))*low+0.005) ((compave(2,1)+compstd(2,1))*low+0.005)],'k-')
plot([x(2,1),x(2,1)], [((compave(1,2)+compstd(1,2))*low+0.0025) ((compave(1,1)+compstd(1,1))*low+0.005)],'k-')
plot([x(2,2),x(2,2)], [((compave(2,2)+compstd(2,2))*low+0.0025) ((compave(2,1)+compstd(2,1))*low+0.005)],'k-')
text(1-0.035, ((compave(1,1)+compstd(1,1))*low+0.015),'#','FontSize',16)
text(2-0.035, ((compave(2,1)+compstd(2,1))*low+0.015),'#','FontSize',16)

high = 1.55;
low = 1.5;
asth = 1.65;
% er = errorbar(t,compave,compstd);
% er(1).LineWidth = 3;
% % er(2).LineWidth = 3;
% er(1).Color = [0 0 0];
% % er(2).Color = [0 0 0];
% er(1).LineStyle = 'none'
% er(2).LineStyle = 'none'

plot([1,1],[(max(compave(:,1))*low) (max(compave(:,1))*high)],'k-') 
plot([1,2],[(max(compave(:,1))*high) (max(compave(:,1))*high)],'k-')
plot([1,2],[(max(compave(:,1))*high) (max(compave(:,1))*high)],'k-')
plot([2,2],[(max(compave(:,1))*high) (max(compave(:,1))*high-max(compave(:,2)))],'k-')
% plot([2,2],[((compave(2,1)+compstd(2,1))*1.05+0.005) (max(compave(:,1))*high)],'k-')
text(mean([1 2]), (max(compave(:,1))*asth), '\ast','FontSize',24)
ax = gca;
ax.LineWidth = 3;
set(gca, 'YTick', [0 0.05 0.1 0.15 0.2 0.25])
ax.FontSize = 22;
ax.FontWeight = 'bold';
% set(gca, 'XTick',xtickid)
ax.XTick = xtickid;
ax.XTickLabels(1)={'\boldmath$\mathsf{Optimal}$'};
ax.XTickLabels(2) = {'\boldmath$\mathsf{Pessimal}$'};
ax.TickLabelInterpreter = 'latex';

ylim([0 0.25])
leg = legend([{'E_1'},{'E_{30}'}],'Position',[0.62 0.75 0.2 0.2],'Orientation','horizontal') % position = [left bottom width height]
xlab = xlabel('\boldmath$\mathsf{Experiment}$','Interpreter','latex','FontSize',22)
ylab = ylabel("\boldmath$\mathsf{E \: [MPa]}$",'Interpreter','latex','FontSize',22)
box on
hold off

opt1 = comp(1:3);
opt30 = comp(4:6);
pes1 = comp(7:9);
pes30 = comp(10:12);
tog1(:,1) = opt1;
tog1(:,2) = pes1;
tog30(:,1) = opt30;
tog30(:,2) = pes30;
xc = 1;
for gee = 1:4
    tog(:,gee) = comp(xc:gee*3);
    xc = xc+3
end
xc = 1;
for gee = 1:2
    tog2(:,gee) = comp(xc:gee*6);
    xc = xc+6
end
% h values
% 1 = reject (significant)

% [hopt2pes1,popt2pes1,ci1,stats] = ttest2(opt1,pes1,'Vartype','unequal')
% [hopt2pes30,popt2pes30,ci2,stats] = ttest2(opt30,pes30,'Vartype','unequal')
% [hopt2opt,popt2opt,ci3,stats] = ttest(opt1,opt30)
% [hpes2pes,ppes2pes,ci4,stats] = ttest(pes1,pes30)



% 
% figure(k+2)
% hold on
% b = bar(t,diamave);
% b(1).LineWidth = 3;
% b(2).LineWidth = 3;
% [ngroups, nbars] = size(diamave);
% % Calculate the width for each bar group
% groupwidth = min(0.8, nbars/(nbars + 1.5));
% % Set the position of each error bar in the centre of the main bar
% % Based on barweb.m by Bolu Ajiboye from MATLAB File Exchange
% for i = 1:nbars
%     % Calculate center of each bar
%     x = (1:ngroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*nbars);
%     errorbar(x, diamave(:,i), diamstd(:,i), 'k', 'linestyle', 'none','linewidth',3);
% end
% % b.FaceColor = [1 1 1];
% % ylim([0 100]);
% box on
% hold off
% 
% c = 1;
% for j = 1:num_doe
%     doe = num2str(j);
%     percentdif(j) = abs((compave(c)-compave(c+1)))/(compave(c))*100;
%     name2(j) = "DOE" + "-" + doe;
%     c = c+2;
% end
% 
% cats = categorical(name2)
% cats = reordercats(cats,name2);
% figure(k+3)
% hold on
% b = bar(cats,diamdiff);
% b.LineWidth = 3;
% % b.FaceColor = [1 1 1];
% ylim([0 100]);
% box on
% hold off




% 
% figure(1)
% hold on
% scatter(strain,stress,1000,'o','LineWidth',2)
% plot(x,y,'LineWidth',3,'Color','r')
% ax = gca;
% 
% ylim([-4000 10000])
% xlim([0 60])
% text(10,5*10^3,['E =' num2str(round(m(1),0)) ' [Pa]'],'Interpreter','tex','FontSize',28,'Color','r')
% ax.LineWidth = 3;
% ax.FontSize = 20;
% ax.FontWeight = 'bold';
% % ax.YScale = 'log'
% xlab = xlabel('strain \epsilon','Interpreter','tex','FontSize',28)
% ylab = ylabel('stress \sigma','Interpreter','tex','FontSize',28)
% box on
% print('compression','-dpng')
% hold off