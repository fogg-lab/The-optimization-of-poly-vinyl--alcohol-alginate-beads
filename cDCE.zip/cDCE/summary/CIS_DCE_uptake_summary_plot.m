clear all;close all;clc
%% Import the data
num_doe = 17;
% base = ["compression\Master_comp_mod"]; %personal
day = ["1","30"];
c = 1;
for i = 1:num_doe
    file(c) = num2str(i) + "\" + day(1) + '.xlsx';
    file(c+num_doe) = num2str(i) + "\"  + day(2) + '.xlsx';
    c = c+1;
end

% figure(1)
% hold on 

mpdc10 = distinguishable_colors(num_doe);


for  k = 1:length(file)

[~, ~, raw] = xlsread(file(k),'Sheet1');
data = raw(4:end,:);

%% Create output variable
% data = reshape([raw{:}],size(raw));

%% Allocate imported array to column variable names
time = [];
datasize = [];
peakarea = [];
concentration = [];

time = cell2mat(data(:,1))./24;
datasize = size(data);
for a = 1:(datasize(2)-1)
peakarea(:,a) = cell2mat(data(:,a+1));
end

%% Clear temporary variables
clearvars data raw;

num_sam = 1;
reps = 3;

vol_l = 100;
vol_g = 65;

m = 0.0018;
b = 3.5*10^(3)*(97^(-1))*10^(6);
H_IB = 0.120;
MW_Cis = 97;

concentration(:,:) = ((peakarea(:,:).*m).*vol_g./1000) + ((peakarea.*m)./H_IB.*vol_l./1000); %umol
% concentration(:,:) = ((peakarea(:,:).*m./H_IB))*MW_Cis; %ppb
sz = size(concentration);

yfit1 = [];


for j = 1:num_sam*reps
    timefit = time(~isnan(concentration(:,j)));
    confit = concentration(~isnan(concentration(:,j)),j);
    yfit1(:,j) = polyfit(timefit,confit,1);
end
fits(k,:) = yfit1(1,:);
mean_control(k) = mean(yfit1(1,((num_sam*reps-2):(num_sam*reps))));
% mean_control = -0.1862;
c = 1;
sz1 = size(yfit1);
for j = 1:num_sam
    for m = 1:sz1(1)
        ratemean(m,j) = mean(yfit1(m,c:(c+reps-1))/mean_control(k));
        ratestd(m,j) = std(yfit1(m,c:(c+reps-1))/mean_control(k));
    end
    c = c+reps;
end

% for j = 1:sz(1)
%     for k = 1:sz(2)
%         c_co(j,k) = concentration(j,k)/concentration(1,k);
%     end
% end
% 
% for i = 1:num_sam*3
% concentration_nonan(:,i) = concentration(~isnan(concentration(:,i)),i);
% end
% concentration(1,c:(c+reps-1)) = 250;
c = 1;
sz = size(concentration);
for i = 1:num_sam
    for m = 1:sz(1)
    c_co_mean(m,i) = mean(concentration(m,c:(c+reps-1))./concentration(1,c:(c+reps-1)));
    c_co_std(m,i) = std(concentration(m,c:(c+reps-1))./concentration(1,c:(c+reps-1)));
    end
    c = c+reps;
end

% UNCOMMENT for rate analysis?
% for i = 1:num_sam*3
% concentration_nonan(:,i) = concentration(~isnan(time),i);
% end
% c = 1;
% sz = size(concentration_nonan);
% for i = 1:num_sam
%     for m = 1:sz(1)
%         concen = concentration_nonan(~isnan(concentration_nonan(:,i)),i);
%     c_co_mean(m,i) = mean(log(concen(m,c:(c+2))));
%     c_co_std(m,i) = std(log(concen(m,c:(c+2))));
%     end
%     c = c+3;
% end

% for i = 1:num_sam
% c_co_mean_nonan(:,i) = c_co_mean(~isnan(c_co_mean(:,i)),i);
% end
% time = time(~isnan(time));
% yfit = [];
% for i = 1:num_sam
% yfit(:,i) = polyfit(time,c_co_mean_nonan(:,i),1);
% end


% c_co_mean = log(c_co_mean)

% for i = 1:num_sam
%     time_disp(:,i) = time(:) + 0.02*i;
% end

sh = ['o','p','s','d','*','x'];

% N=6;
% X = linspace(0,pi*3,1000);
% Y = bsxfun(@(x,n)sin(x+2*n*pi/N), X.', 1:N);
% C = linspace(N);

% display(ratemean)
% display(ratestd)

if k <= num_doe
figure(1)
subplot(1,2,1)
hold on
timetest = time(~isnan(c_co_mean(:,i)))*24;
c_cotest = c_co_mean(:,i);
c_cotest = c_cotest(~isnan(c_cotest));
c_costdtest = c_co_std(:,i);
c_costdtest = c_costdtest(~isnan(c_costdtest));
% fitline = timetest*ratemean(1,i)*mean_control + ratemean(2,i)*mean_control;
er(k) =     errorbar(timetest,c_cotest,c_costdtest,'LineWidth',2,'CapSize',16, 'LineStyle','none','Color', mpdc10(k,:));
pk(k) =     plot(timetest,c_cotest,'-','LineWidth',2,'Marker','o','MarkerSize',10,'Color',mpdc10(k,:));
% line = plot(timetest,exp(fitline))

% hold off

else
figure(1)
subplot(1,2,2)
hold on 
timetest = (time(~isnan(c_co_mean(:,i)))-30)*24;
c_cotest = c_co_mean(:,i);
c_cotest = c_cotest(~isnan(c_cotest));
c_costdtest = c_co_std(:,i);
c_costdtest = c_costdtest(~isnan(c_costdtest));
% fitline = timetest*ratemean(1,i)*mean_control + ratemean(2,i)*mean_control;
pk(k) =     plot(timetest,c_cotest,'-','LineWidth',2,'Marker','o','MarkerSize',10,'Color',mpdc10(k-num_doe,:));
er(k) =     errorbar(timetest,c_cotest,c_costdtest,'LineWidth',2,'CapSize',16, 'LineStyle','none','Color', [pk(k).Color(1),pk(k).Color(2),pk(k).Color(3)]);
% line = plot(timetest,exp(fitline))

% hold off
end

end


% % dt = (5 - 30);

% xticks([0 5 30 35])
% ax.XLim = [0 4];
% ax.YLim = [0 0.5];


subplot(1,2,1)
ax = gca;
ylab = ylabel({'Cis-DCE [umol]'});
ylab.Interpreter = 'tex'
ylab.FontSize = 20;
ylab.FontWeight = 'bold'
t1 = text(40,0.45,'Day 1');
t1.FontSize = 20;
t1.FontWeight = 'bold';
xlim([0 60]);
ylim([0 1.5]);
% xlab = xlabel({'Time [hrs]'});
% xlab.Interpreter = 'tex'
% xlab.FontWeight = 'bold'
% xlab.FontSize = 14;
ax.LineWidth = 3;
ax.FontSize = 20;
ax.FontWeight = 'bold';
% xtic = [0 0.5 1 1.5 2 2.5 3 3.5 4];
% xticlabel = {'0' '0.5' '1' '1.5' '2' ' ' '30' '30.5' '40'};
% ax.XTick = xtic;
% ax.XTickLabel = xticlabel;
% for p = 1:(num_doe-1)
%     legtext(p) = {num2str(p)];
% end
% legtext(num_doe) = 'Poison';
leg = legend([pk(1); pk(2); pk(3); pk(4); pk(5); pk(6);...
    pk(7); pk(8); pk(9); pk(10); pk(11); pk(12); pk(13);...
    pk(14); pk(15); pk(16); pk(17); pk(18)],...
    '1', '2', '3', '4', '5', '6', '7', '8', '9',...
    '10', '11', '12', '13', '14', '15', '16',...
    '17', 'Poison');

leg.Location = 'NorthWest';
leg.Orientation = 'Horizontal';
leg.NumColumns = 6;
box on 
% print('cis_DCE_uptake','-dpdf')
% hold off

figure(1)
hold on
subplot(1,2,2)
xlim([0 6]);
t2 = text(0.5,0.45,'Day 30');
t2.FontSize = 20;
t2.FontWeight = 'bold';
ylim([0 1.5]);
ax = gca;
ax.LineWidth = 3;
ax.FontSize = 20;
ax.FontWeight = 'bold';
ax.YTickLabel = ' ';
box on
% hold off

figure(1)
hold on
xlab = xlabel({'Time [hr after cDCE spike]'});
xlab.Interpreter = 'tex'
xlab.FontWeight = 'bold'
xlab.FontSize = 20;
xlab.Units = 'normalized';
xlab.Position = [-0.15,-0.075,0];
hold off