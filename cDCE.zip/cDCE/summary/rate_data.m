clear all;close all;clc

name2 = [{'1'}, {'30'}];
rates = [0.76921, 4.20305,];
ratestd = [0.437602703, 1.783063671];
cats = categorical(name2)
cats = reordercats(cats,name2);

figure(1)
hold on
b = bar(cats,rates);
er = errorbar(cats,rates,ratestd);
b.LineWidth = 3;
b.FaceColor = 'flat';
b.CData(2,:) = [0.8500    0.3250    0.0980];
er.LineWidth = 3;
er.Color = [0 0 0];
er.LineStyle = 'none'
er.CapSize = 16;
ax = gca;
ax.LineWidth = 3;
ax.FontSize = 20;
ax.FontWeight = 'bold';
% b.FaceColor = [1 1 1];
ylim([0 8])
xlab = xlabel('Day of cDCE spike','Interpreter','tex','FontSize',20)
ylab = ylabel({'cDCE [umol] hr^{-1}';'/ g bead'});
% ylab = ylabel({'Cis-DCE [umol] hr^{-1}'});
xlab.Interpreter = 'tex'
xlab.FontSize = 32;
xlab.FontWeight = 'bold'
ylab.Interpreter = 'tex'
ylab.FontSize = 32;
ylab.FontWeight = 'bold'
box on
hold off