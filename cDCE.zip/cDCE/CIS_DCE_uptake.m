clear all;close all;clc
%% Import the data
[~, ~, raw] = xlsread('1\1.xlsx','Sheet1');
data = raw(4:end,:);

%% Create output variable
% data = reshape([raw{:}],size(raw));

%% Allocate imported array to column variable names
time = cell2mat(data(:,1))./24;
datasize = size(data);
for a = 1:(datasize(2)-1)
peakarea(:,a) = cell2mat(data(:,a+1));
end

%% Clear temporary variables
clearvars data raw;

num_sam = 5;
reps = 3;

vol_l = 100;
vol_g = 65;

m = 1.80E-03;
b = 3.5*10^(3)*(97^(-1))*10^(6);
H_IB = 0.16421;
MW_Cis = 97;

concentration(:,:) = ((peakarea(:,:).*m).*vol_g./1000) + ((peakarea.*m)./H_IB.*vol_l./1000); %umol
% concentration(:,:) = ((peakarea(:,:).*m./H_IB))*MW_Cis; %ppb
sz = size(concentration);

yfit1 = [];


for j = 1:num_sam*reps
    timefit = time(~isnan(concentration(:,j)));
    confit = concentration(~isnan(concentration(:,j)),j);
    yfit1(:,j) = polyfit(timefit,confit,1);
end
mean_control = mean(yfit1(1,((num_sam*reps-2):(num_sam*reps))));
% mean_control = -0.1862;
c = 1;
sz1 = size(yfit1);
for j = 1:num_sam
    for m = 1:sz1(1)
        ratemean(m,j) = mean(yfit1(m,c:(c+reps-1))/mean_control);
        ratestd(m,j) = std(yfit1(m,c:(c+reps-1))/mean_control);
    end
    c = c+reps;
end

% for j = 1:sz(1)
%     for k = 1:sz(2)
%         c_co(j,k) = concentration(j,k)/concentration(1,k);
%     end
% end
% 
% for i = 1:num_sam*3
% concentration_nonan(:,i) = concentration(~isnan(concentration(:,i)),i);
% end

c = 1;
sz = size(concentration);
for i = 1:num_sam
    for m = 1:sz(1)
    c_co_mean(m,i) = mean(concentration(m,c:(c+reps-1)));
    c_co_std(m,i) = std(concentration(m,c:(c+reps-1)));
    end
    c = c+reps;
end

% UNCOMMENT for rate analysis?
% for i = 1:num_sam*3
% concentration_nonan(:,i) = concentration(~isnan(time),i);
% end
% c = 1;
% sz = size(concentration_nonan);
% for i = 1:num_sam
%     for m = 1:sz(1)
%         concen = concentration_nonan(~isnan(concentration_nonan(:,i)),i);
%     c_co_mean(m,i) = mean(log(concen(m,c:(c+2))));
%     c_co_std(m,i) = std(log(concen(m,c:(c+2))));
%     end
%     c = c+3;
% end

% for i = 1:num_sam
% c_co_mean_nonan(:,i) = c_co_mean(~isnan(c_co_mean(:,i)),i);
% end
% time = time(~isnan(time));
% yfit = [];
% for i = 1:num_sam
% yfit(:,i) = polyfit(time,c_co_mean_nonan(:,i),1);
% end


% c_co_mean = log(c_co_mean)

% for i = 1:num_sam
%     time_disp(:,i) = time(:) + 0.02*i;
% end

sh = ['o','p','s','d','*','x'];

% N=6;
% X = linspace(0,pi*3,1000);
% Y = bsxfun(@(x,n)sin(x+2*n*pi/N), X.', 1:N);
% C = linspace(N);

display(ratemean)
display(ratestd)

figure(1)
hold on 
for i = 1:num_sam
timetest = time(~isnan(c_co_mean(:,i)));
c_cotest = c_co_mean(:,i);
c_cotest = c_cotest(~isnan(c_cotest));
c_costdtest = c_co_std(:,i);
c_costdtest = c_costdtest(~isnan(c_costdtest));
fitline = timetest*ratemean(1,i)*mean_control + ratemean(2,i)*mean_control;

pk(i) =     plot(timetest,c_cotest,'-','LineWidth',1.5,'Marker','.','MarkerSize',25,'MarkerFaceColor','auto');
er(i) =     errorbar(timetest,c_cotest,c_costdtest,'LineWidth',1.5,'CapSize',16, 'LineStyle','none','Color', [pk(i).Color(1),pk(i).Color(2),pk(i).Color(3)]);
% line = plot(timetest,exp(fitline))
end 

leg = legend([pk(1);pk(2);pk(3)], 'PVA-Alg',  'Poison', 'Alg');
leg.Location = 'NorthWest';
ax = gca;
% ax.XLim = [0 3];
% ax.YLim = [0 0.5];
ylab = ylabel({'Cis-DCE [umol]'});
ylab.Interpreter = 'tex'
ylab.FontSize = 14;
ylab.FontWeight = 'bold'
xlab = xlabel({'Time [hrs]'});
xlab.Interpreter = 'tex'
xlab.FontWeight = 'bold'
xlab.FontSize = 14;
ax.LineWidth = 3;
ax.FontSize = 14;
ax.FontWeight = 'bold';
box on 
% print('cis_DCE_uptake','-dpdf')
hold off